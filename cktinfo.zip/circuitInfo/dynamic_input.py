
# ==========================================================================================
#  IMPORTS
# ==========================================================================================
import re

try:
	from static import LOCAL_RUN
except:
	try:
		from .static import LOCAL_RUN
	except:
		LOCAL_RUN = True

if LOCAL_RUN:
    from static import CIRCUIT_INPUT_TYPE_MAP, TILDA80
else:
    from .static import CIRCUIT_INPUT_TYPE_MAP, TILDA80, LOCAL_RUN

# ==========================================================================================
#  Validation Functions
# ==========================================================================================

def is_circuit_id(value: str) -> bool:
    pattern = r"^[A-Za-z0-9]{4}[./][0-9]{6}[./]{2}[A-Za-z]{3}$"
    return bool(re.match(pattern, value))


def is_ip_address(value: str) -> bool:
    parts = value.split('.')
    if len(parts) != 4:
        return False
    for part in parts:
        if not part.isdigit():
            return False
        number = int(part)
        if number < 0 or number > 255:
            return False
    return True

def is_isr_order(value: str) -> bool:
    pattern = r"^ISR[a-zA-Z0-9]+-[0-9]{4}$"
    return bool(re.match(pattern, value))


def validate_by_choice(value: str, choice: str) -> bool:
    if choice == '1':
        return is_circuit_id(value)
    if choice == '2':
        return is_ip_address(value)
    if choice == '3':
        return is_isr_order(value)
    return False

# ==========================================================================================
#  Return Dictionary
# ==========================================================================================
def user_input_dict(n, user_input):
    return {
        'ckt_type': 'AVPN',
        'ckt_input_type': CIRCUIT_INPUT_TYPE_MAP[int(n)],
        'ckt_input': user_input,
    }

# ==========================================================================================
#  USER INPUT
# ==========================================================================================
def get_dynamic_user_input():
    try:
        user_input = input('Enter [Circuit ID], [Circuit WAN IP], or [ISR Order number]: ').strip()
    except KeyboardInterrupt:
        print(f"\n[-] User Interrupted")
        return {}
    return return_dynamic_user_input(user_input)

def return_dynamic_user_input(user_input):
    if not user_input: 
        return {}
    print(TILDA80)
    if is_circuit_id(user_input):
        print(f'[{user_input}] recognized as a Circuit ID.')
        return user_input_dict(1, user_input)
    if is_ip_address(user_input):
        print(f'[{user_input}] recognized as an IP address.')
        return user_input_dict(2, user_input)
    if is_isr_order(user_input):
        print(f'[{user_input}] recognized as an ISR Order number.')
        return user_input_dict(3, user_input)

    print(f'[{user_input}] - Input did not match any pre-defined standard format.\n{". "*40}')
    print(f'Select what have you entered:')
    print('1. Circuit ID')
    print('2. IP Address')
    print('3. ISR Order number')

    choice = input('Enter 1, 2, or 3: ').strip()
    if choice not in {'1', '2', '3'}:
        print(f'Invalid selection. Requires (1, 2, or 3). Better luck next time.\n{TILDA80}')
        return {}

    if validate_by_choice(user_input, choice):
        if choice == '1':
            print(f'Input accepted as Circuit ID based on user selection.\n{TILDA80}')
        elif choice == '2':
            print(f'Input accepted as IP Address based on user selection.\n{TILDA80}')
        else:
            print(f'Input accepted as ISR Order number based on user selection.\n{TILDA80}')
    else:
        to_continue = input('Input does not match the selected format, Want to continue (yes/no) [no]: ').strip().lower() or "no"
        if to_continue not in {'yes', 'no', 'ye', 'y', 'n'}:
            print(f'Invalid selection. Cancelling. Retry with correct input.\n{TILDA80}')
            return {}
        if to_continue[0] == 'n':
            print(f'Cancelling Request. Retry with correct input..\n{TILDA80}')
            return {}
        return user_input_dict(choice, user_input)


# ==========================================================================================
#  MAIN PASS
# ==========================================================================================
if __name__ == '__main__': pass
# ==========================================================================================
