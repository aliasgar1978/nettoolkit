# ============================================================================================
#  IMPORTS
# ============================================================================================
from typing import Any, Dict, List, Set, Tuple
import requests

try:
	from static import LOCAL_RUN
except:
	try:
		from .static import LOCAL_RUN
	except:
		LOCAL_RUN = True

if LOCAL_RUN:
	from static import DATASET_URL, STR_ENTRIES, TILDA80
else:
	from .static import DATASET_URL, STR_ENTRIES, TILDA80, LOCAL_RUN

# ============================================================================================
#  BANNERS
# ============================================================================================

def input_banner(input_type=''):
	"""Generate a banner for user input section.
	
	Returns:
		str: Formatted banner string with tildes and section title.
	"""
	return f"{TILDA80}\n\t\t\t{input_type} C I R C U I T  I N F O  R E T R I V A L\n\t\t\t\tV E R S I O N - 1.0\n{TILDA80}\n\n\t\t\t\tU S E R   I N P U T\n"

def request_banner():
	"""Generate a banner for sending requests section.
	
	Returns:
		str: Formatted banner string with tildes and section title.
	"""
	return f"{TILDA80}\nGathering Info."
	# text = "S E N D I N G   R E Q U E S T S"
	# return _get_centered_text(text)

def response_banner():
	"""Generate a banner for responses section.
	
	Returns:
		str: Formatted banner string with tildes and section title.
	"""
	text = "R E S P O N S E S"
	return _get_centered_text(text)

def json_banner():
	"""Generate a banner for json section.
	
	Returns:
		str: Formatted banner string with tildes and section title.
	"""
	text = f"J S O N"
	return _get_centered_text(text)

def summary_banner(for_input):
	"""Generate a banner for summary section.
	
	Returns:
		str: Formatted banner string with tildes and section title.
	"""
	text = f"S U M M A R Y [{for_input}]"
	return _get_centered_text(text)

def _get_centered_text(text, length=80):
	return f"{TILDA80}\n{text.center(length)}\n{TILDA80}\n"

# ============================================================================================
#  INPUT FUNCS
# ============================================================================================

def get_user_inputs(user_inputs):
	"""Collect user inputs for all defined input types.
	
	Iterates through USER_INPUTS and prompts user for each input type using
	the validation rules defined in the input configuration.
	
	Returns:
		dict: Dictionary mapping input types to validated user inputs.
	"""
	return {ui_type: _get_input_while_true(**ui_dict) for ui_type, ui_dict in user_inputs.items()}

def _get_input_while_true(input_description, default='', valid_inputs=(), input_help_banner=''):
	"""Prompt user for input with validation in a loop until valid input is received.
	
	Continuously prompts the user for input and validates against allowed values.
	Supports default values, custom help text, and integer validation.
	
	Args:
		input_description (str): Text to display in the input prompt.
		default (str, optional): Default value if user provides empty input. Defaults to ''.
		valid_inputs (tuple, optional): Tuple of allowed input values. If empty, any non-empty input is valid. Defaults to ().
		input_help_banner (str, optional): Help text to display with the prompt. Defaults to ''.
	
	Returns:
		str or int: Validated user input. Returns integer if input is digit and in valid_inputs.
	"""
	_input_help_banner = f"\n {input_help_banner}" if input_help_banner else ""
	_default = f"\n[{default}] ->" if default else ""
	while True:
		ui = input(f"{input_description}:{_input_help_banner}{_default}" ).strip()
		if not ui:
			ui = default
		if not valid_inputs and ui:
			return ui
		if ui in valid_inputs :
			print("OK")
			return ui
		if ui.isdigit() and int(ui) in valid_inputs:
			print("OK")
			return int(ui)
		print(f"[-] Invalid or bad input, retry.")

# ============================================================================================
#  REQUESTs
# ============================================================================================

def get_responce(api_req_args):
	"""Send a POST request to the dataset API endpoint.
	
	Args:
		api_req_args (dict): Request parameters to send to the API.
	
	Returns:
		requests.Response: Response object from the API request.
	"""
	return requests.post(DATASET_URL, data=api_req_args)


# ============================================================================================
#  SEARCH KEY
# ============================================================================================

def get_value_of_key_from_dict(d, key):
	"""Recursively search for all values associated with a given key in a nested data structure.
	
	Searches through nested dictionaries, lists, sets, and tuples to find all values
	matching the specified key. Handles both direct key-value pairs and nested structures.
	
	Args:
		d (dict, list, set, tuple): The data structure to search.
		key: The key to search for.
	
	Returns:
		set: Set of all values found for the given key. Returns empty set if key not found.
	"""
	values = set()
	if isinstance(d, dict):
		for k, v in d.items():
			if k == key: return {v,}
			if isinstance(v, (dict, list, set, tuple)):
				rv = get_value_of_key_from_dict(v, key)
				if isinstance(rv, str):
					values.add(rv)
				elif isinstance(rv, set):
					if rv: 
						values = values|rv
	elif isinstance(d, (list, set, tuple)):
		for i, item in enumerate(d):
			rv = get_value_of_key_from_dict(item, key)
			if isinstance(rv, str):
				values.add(rv)
			elif isinstance(rv, set):
				if rv: 
					values = values|rv
	return values



# ==========================================================================================
#  Common function // Serialize values for display
# ==========================================================================================
def serialize_values(data: dict[str, Any], recursive: bool = False, exceptions: list[str] = []) -> dict[str, Any]:
	"""Flatten singleton containers in extracted values for display."""
	result: dict[str, Any] = {}
	for key, value in data.items():
		if key in exceptions:
			result[key] = value
			continue
		elif isinstance(value, dict) and recursive:
			result[key] = serialize_values(value, recursive=True)
		elif isinstance(value, (set, list)) and len(value) == 1:
			result[key] = next(iter(value))
		else:
			result[key] = value
	return result

def serialize_values_vpn(
	data: dict[str, dict[str, Any]]
	) -> dict[str, dict[str, Any]]:
	"""Serialize nested PVC values recursively for table rendering."""
	return {key: serialize_values(value, recursive=True) for key, value in data.items()}
	
# def serialize_segments_dict(segments_dict: dict[str, Any]) -> dict[str, Any]:
# 	"""Convert nested segment dictionaries into a flat field mapping."""
# 	result: dict[str, Any] = {}
# 	if isinstance(segments_dict, dict):
# 		v4data = segments_dict.get('V4Data', {})
# 		if isinstance(v4data, dict):
# 			## BGP 
# 			bgp = v4data.get('BGPNeighborAddress', {})
# 			if isinstance(bgp, dict) and 'ipAddress' in bgp:
# 				result['BGP Neighbor'] = bgp['ipAddress']
# 			if 'customerASN' in v4data:
# 				result['Customer ASN'] = v4data['customerASN']

# 			# ## WAN Subnet
# 			# wan = v4data.get('V4WANIpAddress', {})
# 			# if wan and isinstance(wan, dict) and 'perIPAddress' in wan:
# 			# 	result['PE IP Address'] = wan['perIPAddress']
# 			# if wan and isinstance(wan, dict) and 'cerIPAddress' in wan:
# 			# 	result['CE IP Address'] = wan['cerIPAddress']
# 			# if wan and isinstance(wan, dict) and 'addressMask' in wan:
# 			# 	result['WAN Subnet Mask'] = wan['addressMask']

# 			# ## LAN Subnets
# 			# lan_prefixes = v4data.get('V4LANIpPrefixes', [])
# 			# if lan_prefixes:
# 			# 	if isinstance(lan_prefixes, list):
# 			# 		for i, lan in enumerate(lan_prefixes):
# 			# 			result[f'LAN Subnet {i+1}'] = f"{lan.get('ipAddress', '')}/{lan.get('length', '')}"
# 			# 	elif isinstance(lan_prefixes, dict):
# 			# 		result['LAN Subnet'] = f"{lan_prefixes.get('ipAddress', '')}/{lan_prefixes.get('length', '')}"

# 		# wan = segments_dict.get('V4WANIpAddress', {})                       ### LABEL~1
# 		# if isinstance(wan, dict):
# 		# 	result.update(wan)

# 	return result

# def serialize_pvc_dict(pvc_fields: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
# 	"""Prefix PVC field keys for display and identification."""
# 	return {
# 		pvc: {f'pvc-{pvc}-{k}': v for k, v in pvc_dict.items()}
# 		for pvc, pvc_dict in pvc_fields.items()
# 	}




# ============================================================================================
#  TABLE FORMATTING
# ============================================================================================

class PrintFormattedTable():

	max_v_length = 120
	k_max = 30
	v_max = 20

	# -------------- FORMATTING -------------- #
	def table_header(self):
		print(f"+{'='*self.k_max}+{'='*self.v_max}+")
		print(f"|{'Description'.center(self.k_max)}|{'Value'.center(self.v_max)}|")
		print(f"|{'='*self.k_max}+{'='*self.v_max}|")

	def table_footer(self):
		print(f"+{'='*self.k_max}+{'='*self.v_max}+")

	def print_section_header(self, k, v):
		print(f"+{'-'*self.k_max}+{'-'*self.v_max}+")
		print(f"|{k.center(self.k_max)}|{v.center(self.v_max)}|")
		print(f"+{'-'*self.k_max}+{'-'*self.v_max}+")

	# -------------- Kick -------------- #
	def __call__(self, **fields):
		self.set_max_field_length(**fields)
		if self.no_response:
			print(f"[-] NO RESPONSE RECEIVED.\n{TILDA80} ")
			return
		self.table_header()
		self.table_general_info(fields['d'])
		self.table_pvc_fields(fields['pvc_fields'])
		self.table_sections_general(fields['segments_fields'])
		self.table_sections_per(fields['segments_fields'])
		self.table_footer()

	# -------------- Adjust field width -------------- #
	def set_max_field_length(self, **fields):
		self.no_response = True
		v_max = self.v_max
		self.general_fields, pvc_fields, segment_fields = fields['d'], fields['pvc_fields'], fields['segments_fields']
		for d in (self.general_fields, pvc_fields, segment_fields):
			v_max = max (self.get_v_max_of_dict(d, v_max), v_max)
		v_max = min( v_max, self.max_v_length)
		self.v_max = v_max

	def get_v_max_of_dict(self, d, v_max):
		for k, v in d.items():
			if self.no_response and v: self.no_response = False
			key = self.get_key_name(k)
			if isinstance(v, str):
				v_max = max(len(v), v_max)
			elif isinstance(v, dict):
				v_max = max(self.get_v_max_of_dict(v, v_max), v_max)

			elif d is self.general_fields:
				v_max = max(len(str( self.shrink_exceptional_general_fields(k, v))) , v_max  )

			else:
				v_max = max(len(str(v)), v_max)

		return v_max

	## =============== Exceptionals =============== ##

	@staticmethod
	def shrink_exceptional_general_fields(k, v):
		if k in STR_ENTRIES and isinstance(v, (set, list, tuple)):
			if len(set(v)) == 1:
				v = v[0]
		elif isinstance(v, (set, list, tuple)):
			v = set(v)
		return v

	## =============== INDIVIDUAL SECTIONS PRINT =============== ##


	def table_general_info(self, fields):
		for k, v in fields.items():
			key = self.get_key_name(k)
			v = self.shrink_exceptional_general_fields(k, v)
			self.send_table_data(key, v)

	def table_pvc_fields(self, fields):
		pvc_fields = serialize_values_vpn(fields)
		for pvc, value in pvc_fields.items():
			self.print_section_header("PVC ID", pvc)
			for k, v in value.items(): 
				key = self.get_key_name(k)
				self.send_table_data(key, v)

	def table_sections_general(self, segments_fields):
		for segment, value in segments_fields.items():
			if not value: continue
			if segment in ('PER INFO', ): continue
			self.print_section_header(segment, "")
			for k, v in value.items(): 
				key = self.get_key_name(k)
				self.send_table_data(key, v)

	def table_sections_per(self, segments_fields):
		for segment, value in segments_fields.items():
			if not value: continue
			if segment not in ('PER INFO', ): continue
			for s, sd in value.items():
				self.print_section_header("SERVICE SEGMENT", s)
				for k, v in sd.items(): 
					key = self.get_key_name(k)
					if isinstance(v, list) and len(set(v)) == 1:
						self.send_table_data(key, v[0])
					else:
						self.send_table_data(key, v)

	# -------------- Common for above -------------- #

	def send_table_data(self, key, v):
		if len(str(v)) < self.max_v_length: v = str(v)
		if isinstance(v, (str,int)):
			self.table_data(key ,v, 0)

		if isinstance(v, (set, tuple, list)):
			for i, _v in enumerate(v):
				self.table_data(key ,_v, i)

	def table_data(self, k ,v, redord_index):
		if self.v_max < self.max_v_length or len(str(v)) < self.max_v_length:
			key = k  if redord_index==0 else ""							
			print(f"|{key.ljust(self.k_max)}|{str(v).ljust(self.v_max)}|")               ##########
		else:
			desc_i = 0
			c = [v[i:i + self.v_max] for i in range(0, len(v), self.v_max)]
			for _c in c:
				key = k  if redord_index==0 and desc_i==0 else ""							
				print(f"|{key.ljust(self.k_max)}|{str(_c).ljust(self.v_max)}|")               ##########
				desc_i += 1

	# -------------- buggy -------------- #

	def get_key_name(self, k):
		dics = [self.fields_to_retrieve, self.pvc_fields]
		for d in dics:
			value = d.get(k)
			if value: return value
			for key_tuple, value in d.items():
				if not isinstance(key_tuple, (tuple)): continue
				if k in key_tuple:
					return value
		return k





# ============================================================================================
#  pass
# ============================================================================================
if __name__ == "__main__": pass
# ============================================================================================
