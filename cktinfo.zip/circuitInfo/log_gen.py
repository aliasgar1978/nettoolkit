
# =================================================================================================
#  Imports
# =================================================================================================
import os
import datetime as dt
from getpass import getpass

try:
	from static import LOCAL_RUN
except:
	try:
		from .static import LOCAL_RUN
	except:
		LOCAL_RUN = True

# =================================================================================================
#  STATICS
# =================================================================================================

if LOCAL_RUN:
    from static import LOCAL_RUN
    LOG_FILE = "./log/cktInfo_script.log"
    USER = 'al202t'
else:
    try:
        import fcntl
    except:
         pass
    from .static import LOCAL_RUN
    LOG_FILE = "/home/m98484/bin/log/cktInfo_script.log"
    USER = os.environ.get('USER', 'unknown')

# =================================================================================================
#  Log Appending function / From Sibi
# =================================================================================================
def append_execution_log(activity):
    """Append a log entry for an execution activity.
    The log entry includes timestamp & user
    timestamp format YYYY-MM-DD HH:MM:SS
    """
    log_dir = os.path.dirname(LOG_FILE)

    if log_dir:
        os.makedirs(log_dir, exist_ok=True)

    timestamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # # option1: using USER environment variable
    # line = f"{timestamp}|{USER}|{activity}\n"

    # option2 : using SUDO_USER environment variable if available, else fallback to USER
    sudo_user = get_sudo_user()
    line = f"{timestamp}|{sudo_user}|{activity}\n"

    with open(LOG_FILE, "a", encoding="utf-8") as log_f:
        if not LOCAL_RUN:
            try:
                fcntl.flock(log_f.fileno(), fcntl.LOCK_EX)
            except : pass

        try:
            log_f.write(line)
            log_f.flush()
            os.fsync(log_f.fileno())
        finally:
            if not LOCAL_RUN:
                try:
                    fcntl.flock(log_f.fileno(), fcntl.LOCK_UN)
                except: pass
 
def get_originator():
    """Return the original user who initiated the process.

    This function attempts to determine the originator in the following order:
    1. The SUDO_USER environment variable (if present).
    2. The currently logged in user via getpass.getuser().
    3. The USER environment variable.
    4. The literal string 'unknown' if no other value is found.

    Returns:
        str: Username of the originator (never empty; falls back to 'unknown').
    """
    sudo_user = os.getenv("SUDO_USER", "").strip()
    if sudo_user:
        return sudo_user

    try:
        return getpass.getuser().strip()
    except Exception:
        return (os.getenv("USER", "") or "unknown").strip() or "unknown"


def get_sudo_user():
    """Return the effective sudo user for this process.

    This returns the value of the SUDO_USER environment variable if set
    and non-empty (with surrounding whitespace stripped). If SUDO_USER is
    not set or is empty, the function falls back to get_originator().

    Returns:
        str: Username representing the sudo/originating user.
    """

    return os.getenv("SUDO_USER", "").strip() or get_originator()

# =================================================================================================
# File main
# =================================================================================================
if __name__ == "__main__":
    pass
# =================================================================================================