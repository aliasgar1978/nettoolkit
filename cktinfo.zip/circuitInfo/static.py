
# ============================================================================================
#  Imports
# ============================================================================================
from collections import OrderedDict

# ============================================================================================
#  DATA SET ENDPOINT URL
# ============================================================================================
DATASET_URL = 'http://schedule.web.att.com/ictool_ba/stats/api/scrt/api.php?type=wds'

# ============================================================================================
#  STATICs
# ============================================================================================
TILDA80 = "~"*80
LOCAL_RUN = False
# ============================================================================================
#  SHORT-CUTS
# ============================================================================================

####### LOCATIONS #######
US = "US"
MOW = "MOW"

####### CIRTUIT TYPES #######
AVPN, ADI, MIS = 'AVPN', 'ADI', 'MIS'

####### INPUT TYPES #######
CKT_ID =      "CIRCUIT-ID  [XXXX.YYYYY..ZZZ]"
IP =          "IP-ADDRESS  [A.B.C.D]"
SITE_ID =     "SITE-ID     [nnnnnnn]"
VPN_ID =      "VPN-ID      [nnnnnnn]"
PA_ID =       "PA_ID       [nnnnnnn]"
SALES_ORDER = "SALES-ORDER [IPnnnnnnnn]"
USRP_ORDER  = "USRP ORDER  [nnnnnnn]"
ISR_ORDER   = "ISR ORDER   [ISRxxxxxxxx-xxxx]"

KEY_INFO_MAP = {
	CKT_ID     : "Ckt",
	IP         : "Ip",
	SITE_ID    : "Site",
	VPN_ID     : "Vpn",
	PA_ID      : "Pa",
	SALES_ORDER: 'SalesOrder',
	USRP_ORDER : 'UsrpOrder',
	ISR_ORDER  : 'IsrOrder',
}

####### SEARCH FIELDS IN PREVIOUS OUTPUT TO CASCADE API CALL #######
SEARCH_REQ_FIELDS = {
	IP: ("ipfr_per_ip_address", "perIPAddress", ),
	CKT_ID: ("custaccess_acc_ckt",),
	VPN_ID: ('pvc_pvc_id', "icorePVCId", "icore_pvc_id", "bookkeep_icore_pvc_id"),
	SITE_ID: ("order1pvc_icore_side_id",),
	# PA_ID: ("layer3PortAssignmentId",),
}

# ============================================================================================
#  DATASETS MAPS 
# ============================================================================================

APIG0006 = {
	'ckt_input_type': (CKT_ID, ),
	'api_req_key': ('access_circuit_id', ),        
}
DS0078 = {
	'ckt_input_type': (CKT_ID, ),
	'api_req_key': ('access_circuit_id', ),        
}
DS0011 = {
	'ckt_input_type': (IP, ),
	'api_req_key': ('wan_ip', ),        
}
DS0056 = {
	'ckt_input_type': (SITE_ID, ),
	'api_req_key': ('icore_site_id', ),        
}
DS0010 = {
	'ckt_input_type': (VPN_ID, ),
	'api_req_key': ('icore_pvc_id', ),        
}

CAPIG0005 = {
	'ckt_input_type': (CKT_ID, ),
	'api_req_key': ('general_circuit_id', ),        
}
DS0029 = {
	'ckt_input_type': (SALES_ORDER, ),
	'api_req_key': ('sales_order_number', ),        
}
OB0012 = {
	'ckt_input_type': (USRP_ORDER, ),
	'api_req_key': ('usrp_order_number', ),        
}
# --------------- new unused and untested -----------
DS0009 = {
	'ckt_input_type': (CKT_ID, ),
	'api_req_key': ('general_circuit_id', ),        
}

DS0016 = {
	'ckt_input_type': (PA_ID, ),
	'api_req_key': ('port_assignment_id', ),        
}
DS0083 = {
	'ckt_input_type': (USRP_ORDER, ),
	'api_req_key': ('usrp_order_number', ),        
}

CDS0008 = {
	'ckt_input_type': (ISR_ORDER, ),
	'api_req_key': ('giom_order_number', ),        
}

# ==========================================================================================
#  DATASET to CIRCUIT MAPPING
# ==========================================================================================

########## AVPN CIRCUITS ##################
AVPN_CKT = {"ckt_type": (AVPN, )}
AVPN_UTIL_MAP = { 
	"APIG-0006": {**APIG0006, **AVPN_CKT},
	"DS-0078"  : {**DS0078, **AVPN_CKT},
	"DS-0011"  : {**DS0011, **AVPN_CKT},
	"DS-0056"  : {**DS0056, **AVPN_CKT},
	"DS-0010"  : {**DS0010, **AVPN_CKT},
	"CDS-0008" : {**CDS0008, **AVPN_CKT},
}

########## ADI CIRCUITS ##################
ADIG_CKT = {"ckt_type": (ADI, )}
ADIG_UTIL_MAP = {
	"CAPIG-0005": {**CAPIG0005, **ADIG_CKT}, 
	"DS-0029": {**DS0029, **ADIG_CKT}, 
	"OB-0012": {**OB0012, **ADIG_CKT}, 
	"DS-0010": {**DS0010, **ADIG_CKT},

}

# ==========================================================================================
#  CLUBBING ALL CIRCUIT TYPES TO SINGLE
# ==========================================================================================
DS_UTIL_MAP = {}
DS_UTIL_MAP.update(AVPN_UTIL_MAP)
DS_UTIL_MAP.update(ADIG_UTIL_MAP)

# ============================================================================================
#  MAPS for MANUAL USER INPUTS
# ============================================================================================
LOCATION_MAP = { i+1: input for i, input in enumerate([US, MOW])}
	# 1: US,
	# 2: MOW,

CIRCUIT_TYPE_MAP = { i+1: input for i, input in enumerate([AVPN, ADI]) }
# 	1: AVPN, 
# 	2: ADI, 
#	# 3: MIS, 


CIRCUIT_INPUT_TYPE_MAP = { i+1: input for i, input in enumerate([ CKT_ID, IP, ISR_ORDER ])}
# 	1: CKT_ID, 
# 	2: IP, 
# 	# 3: SITE_ID, 
# 	# 4: VPN_ID,
# 	# 5: PA_ID,
# 	6: SALES_ORDER,

USER_INPUTS = {
	# 'location': {
	# 	'input_help_banner': "".join(f"\t[{i}]: {s}\n" for i, s in LOCATION_MAP.items()),
	# 	 'valid_inputs': LOCATION_MAP, 
	# 	 'input_description': 'Provide Location',
	# 	 'default': 1,
	# },

	# 'ckt_type': {           ######## DISABLED #######
	# 	'input_help_banner': "".join(f"\t[{i}]: {s}\n" for i, s in CIRCUIT_TYPE_MAP.items()),
	# 	 'valid_inputs': CIRCUIT_TYPE_MAP, 
	# 	 'input_description': 'Provide Circuit Type',
	# 	 'default': 1,
	# },

	'ckt_input_type': {
		'input_help_banner':  "".join(f"\t[{i}]: {s}\n" for i, s in CIRCUIT_INPUT_TYPE_MAP.items()),
		 'valid_inputs': CIRCUIT_INPUT_TYPE_MAP, 
		 'input_description': 'What information you have?',
		 'default': 1,
	},
	'ckt_input': {'input_description': 'Provide Your Input',
	},
	
}

# ============================================================================================
#  FILTERS
# ============================================================================================
def on_location(location, d=DS_UTIL_MAP):
	return {k:v for k, v in d.items() 
		#  if location in v['location'] 
	}

def on_ckt_type(ckt_type, d=DS_UTIL_MAP):
	return {k:v for k, v in d.items() 
		#  if ckt_type in v['ckt_type'] 
	}

def on_ckt_input_type(ckt_input_type, d=DS_UTIL_MAP):
	return {k:v for k, v in d.items() if ckt_input_type in v['ckt_input_type'] }

def on_api_req_key(api_req_key, d=DS_UTIL_MAP):
	return {k:v for k, v in d.items() if api_req_key in v['api_req_key'] }

def _get_ckt_input_type_from_api_req_key(d, api_req_key):
	try:
		return d['api_req_key'][d['ckt_input_type'].index(api_req_key)]
	except ValueError:
		return "Unknown"

def get_key_info(d, api_req_key):
	return _get_ckt_input_type_from_api_req_key(d, api_req_key)

def get_available_req_datasets(d, collected):
	return {k:v for k, v in d.items() if k not in collected}

def _get_ckt_input_type_from_api_req_key2(d, api_req_key):
	try:
		return d['ckt_input_type'][d['api_req_key'].index(api_req_key)]
	except ValueError:
		return "Unknown"

def search_ckt_input_type_fields(d, api_req_key):
	return SEARCH_REQ_FIELDS.get(_get_ckt_input_type_from_api_req_key2(d, api_req_key))

# ============================================================================================


# ============================================================================================
#  FIELDS to be retrived FROM JSON
# ============================================================================================

COMMON_FIELDS_TO_RETRIVE = OrderedDict()
COMMON_FIELDS_TO_RETRIVE[('customerName', 'customer_cust_name')] = 'Customer Name'
COMMON_FIELDS_TO_RETRIVE[('country', 'premise_country_name')] = 'Country'
COMMON_FIELDS_TO_RETRIVE[('custaccess_vendorname', 'custaccess_vendor_name')] = 'LEC Name'
COMMON_FIELDS_TO_RETRIVE[('custaccess_vendor_cktname', 'vendorCircuitName')] = 'LEC Circuit ID'
COMMON_FIELDS_TO_RETRIVE['custaccess_acc_ckt'] = 'ATT Circuit ID'
COMMON_FIELDS_TO_RETRIVE['projects_proj_name'] = 'Project ID'
COMMON_FIELDS_TO_RETRIVE[('icore_side_id', 'order1pvc_icore_side_id')] = 'SITE ID'
COMMON_FIELDS_TO_RETRIVE['order1port_port_uso'] = 'PORT USO ID'
COMMON_FIELDS_TO_RETRIVE[('ip_port_asgmt_id', )] = 'PA ID'

STR_ENTRIES = ('customerName', 'country', 'custaccess_vendorname', 'custaccess_vendor_cktname',
	'custaccess_acc_ckt', 'projects_proj_name', 'icore_side_id', 'order1port_port_uso')

PVC_FIELDS_TO_RETRIVE = OrderedDict()
PVC_FIELDS_TO_RETRIVE[( 'order1pvc_pvc_id', 'icorePVCId',)] = 'PVC ID' 
PVC_FIELDS_TO_RETRIVE['pvc_pvc_stat'] = 'PVC Status'
PVC_FIELDS_TO_RETRIVE['ipfr_ip_port_asgmt_id'] = 'INSTAR PA ID'
PVC_FIELDS_TO_RETRIVE['order1pvc_pvc_uso'] = 'PVC USO ID'
PVC_FIELDS_TO_RETRIVE['portinttype_int_type'] = 'Interfae Type'
PVC_FIELDS_TO_RETRIVE[('ipfr_per_ip_address',)] = 'PER IP Address'
PVC_FIELDS_TO_RETRIVE[('ipfr_cpe_ip_address',)] = 'CER IP Address'
PVC_FIELDS_TO_RETRIVE[('ipfr_address_mask',  )] = 'Subnet Mask'
PVC_FIELDS_TO_RETRIVE['pvcext_c_vlanid_bot'] = 'Customer VLAN ID'

PER_FIELDS_TO_RETRIVE = OrderedDict()
PER_FIELDS_TO_RETRIVE[('servacpt_segment',)] = 'Service Segment'
PER_FIELDS_TO_RETRIVE[('equipment_eqp_name_code',)] = 'Equipment Name Code'
PER_FIELDS_TO_RETRIVE[('equipment_equip_name',)] = 'EGS/PER'
PER_FIELDS_TO_RETRIVE[('naport_interface_string',)] = 'EGS/PER Interface'
PER_FIELDS_TO_RETRIVE[('service_serv_name',)] = 'Service Type'
PER_FIELDS_TO_RETRIVE[('naport_protocol',)] = 'PROTOCOL'
# PER_FIELDS_TO_RETRIVE[('naport_description',)] = 'EGS/PER Interface Description'


# ==========================================================================================
#  Defined Segments with its necessary fields 
# ==========================================================================================
SEGMENTS = {
	'BGP': {
		'key': 'BGPNeighborAddress',
		'fields': {
			'BGP Neighbor': 'ipAddress',
			'Customer ASN': 'customerASN',
		}
	},
	'WAN Subnet': {
		'key': 'V4WANIpAddress',
		'fields': {
			'PE IP': 'perIPAddress',
			'CE IP': 'cerIPAddress',
			'SUBNET MASK': 'addressMask',
		}
	},
	'LAN Subnets': {
		'key': 'V4LANIPAddresses',
		'fields': {
			'LAN Subnet': 'ipAddress',
			'SUBNET MASK': 'length',
		}
	},
	'PER INFO':{
		'key': 'circuitDetails',
		'fields':{
			'Service Segment': 'servacpt_segment',
			'Service Type': 'service_serv_name',
			'EGS/PER': 'equipment_equip_name',
			'EGS/PER Interface': 'naport_interface_string',
			'Equipment Name Code': 'equipment_eqp_name_code',
		}
	}
}

# ==========================================================================================
#  MAIN PASS
# ==========================================================================================
if __name__ == '__main__': pass
# ==========================================================================================