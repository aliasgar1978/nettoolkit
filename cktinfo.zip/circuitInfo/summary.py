
# =================================================================================================
#  Imports
# =================================================================================================

from typing import Any, Dict, List, Set, Tuple
from dataclasses import dataclass, field

try:
	from static import LOCAL_RUN
except:
	try:
		from .static import LOCAL_RUN
	except:
		LOCAL_RUN = True

if LOCAL_RUN:
	from static import COMMON_FIELDS_TO_RETRIVE, PVC_FIELDS_TO_RETRIVE, SEGMENTS, PER_FIELDS_TO_RETRIVE, LOCAL_RUN
	from common import PrintFormattedTable, serialize_values
else:
	from .static import COMMON_FIELDS_TO_RETRIVE, PVC_FIELDS_TO_RETRIVE, SEGMENTS, PER_FIELDS_TO_RETRIVE, LOCAL_RUN
	from .common import PrintFormattedTable, serialize_values

# ==========================================================================================
#  Common function // Retrive value/item from dict
# ==========================================================================================

def find_all_keys(
	container: Any,
	target_key: str,
	stop_at_first_level: bool = False,
	seen_ids: Set[int] = None,
	) -> List[Any]:
	"""Recursively search for all occurrences of a key in a nested dictionary or list.
	"""
	if seen_ids is None:
		seen_ids = set()

	if isinstance(container, dict):
		if stop_at_first_level and target_key in container:
			return [container[target_key]]

		matches: List[Any] = []
		for k, v in container.items():
			if k == target_key:
				if id(v) not in seen_ids:
					seen_ids.add(id(v))
					if v: matches.append(v)
			if isinstance(v, (dict, list, set, tuple)):
				matches.extend(
					find_all_keys(v, target_key, stop_at_first_level=False, seen_ids=seen_ids)
				)
		return matches

	if isinstance(container, (list, set, tuple)):
		matches: List[Any] = []
		for item in container:
			matches.extend(find_all_keys(item, target_key, stop_at_first_level=False, seen_ids=seen_ids))
		return matches

	return []

def get_value_of_key_from_dict(container: Any, target_key: str) -> list[Any]:
	"""Find values for the target key anywhere in the container."""
	return find_all_keys(container, target_key, stop_at_first_level=False)

def get_dict_of_key_from_dict(container: Any, target_key: str) -> list[Any]:
	"""Find nested dictionaries for the target key anywhere in the container."""
	return find_all_keys(container, target_key, stop_at_first_level=False)

def is_duplicate_of_pvc(ip, pvc_fields):
	for pvc_id, pvc_data in pvc_fields.items():
		for k, v in pvc_data.items():
			if ip in v or ip == v:
				return True
	return False

# ==========================================================================================
#  Common function // Unwrap 
# ==========================================================================================

def unwrap_singleton_containers(data: Any) -> Any:
	"""Recursively unwrap single-item lists into their contained value."""
	if isinstance(data, list) and len(data) == 1:
		return unwrap_singleton_containers(data[0])
	if isinstance(data, dict):
		return {k: unwrap_singleton_containers(v) for k, v in data.items()}
	return data

def remove_nested_list(d):
	nd = {}
	if isinstance(d, list) and len(d) == 1:
		return remove_nested_list(d[0])
	if isinstance(d, dict):
		for k, v in d.items():
			nd[k] = remove_nested_list(v)
	if isinstance(d, (str,int)):
		return d  
	return nd


# ==========================================================================================
#  Extractor class
# ==========================================================================================

@dataclass
class Extract(PrintFormattedTable):
	d: dict = field(default_factory=dict)

	fields_to_retrieve = COMMON_FIELDS_TO_RETRIVE
	pvc_fields = PVC_FIELDS_TO_RETRIVE
	segments = SEGMENTS
	per_fields = PER_FIELDS_TO_RETRIVE
	pvc_identifier = ['order1pvc_pvc_id',]
	segments_to_retrieve = {					## all values must be in tuples.
		# ('V4WANIpAddress', ), 	                       							### LABEL~1
		('V4Data', 'AVPNParameters'),
		('V4Data', 'BGPNeighborAddress'),
		('V4Data', 'V4WANIpAddress'),
		('V4Data', 'V4LANIPAddresses'),
		('circuitDetails', ),
	} 

	def __call__(self):
		fields = serialize_values( self.general_fields(), exceptions=self.pvc_identifier)
		per_fields = self.retrieve_fields(self.per_fields)
		pvc_fields = self.extract_pvc_entries(self.d, fields)
		segments_fields = self.extract_segments_entries(pvc_fields, per_fields)
		# print(segments_fields)
		super().__call__(d=fields, pvc_fields=pvc_fields, segments_fields=segments_fields)

	def retrieve_fields(self, field: dict[str, Any]) -> dict[str, Any]:
		results_dict = {}
		for fields_tuple in list(field.keys()):
			for i, field in enumerate(fields_tuple):
				v = get_value_of_key_from_dict(self.d, field)
				if v:
					if results_dict.get(field):
						if isinstance(results_dict[field], list):
							results_dict[field].extend(v)
						else:
							results_dict[field] = [results_dict[field]] + v
					else:
						results_dict[field] = v
					# break
			if not results_dict.get(field):
				results_dict[field] = []
		return results_dict

	def general_fields(self):
		results_dict = {}
		for f in list(self.fields_to_retrieve.keys()) + self.pvc_identifier:
			if isinstance(f, str):
				v = find_all_keys(self.d, f)
				if f in self.pvc_identifier:
					if not results_dict.get(f):
						results_dict[f] = []
					results_dict[f].extend(v)
				else:
					results_dict[f] = v
			elif isinstance(f, tuple):
				for i, f1 in enumerate(f):
					v = find_all_keys(self.d, f1)
					if v:
						results_dict[f1] = v
						break
				if not results_dict.get(f1):
					results_dict[f1] = []
		return results_dict

	def extract_segments(self, data: dict[str, Any]) -> dict[str, Any]:
		"""Extract segment-specific nested dictionaries from the dataset."""
		segments_dict: dict[str, Any] = {}
		for segment_path in self.segments_to_retrieve:
			if len(segment_path) == 1:
				segments_dict[segment_path[0]] = get_dict_of_key_from_dict(data, segment_path[0])
			else:
				intermediate = get_dict_of_key_from_dict(data, segment_path[0])
				segments_dict[segment_path[1]] = get_dict_of_key_from_dict(
					intermediate, segment_path[1]
				)

		return unwrap_singleton_containers(segments_dict)


	def extract_pvc_entries(
		self, data: dict[str, Any], fields: dict[str, Any]
		) -> dict[str, dict[str, Any]]:
		"""Extract PVC-specific entries from the dataset using existing fields."""
		pvc_id = fields.get('order1pvc_pvc_id')
		if not pvc_id:
			return {}

		pvc_ids = [pvc_id] if isinstance(pvc_id, str) else pvc_id
		results: dict[str, dict[str, Any]] = {}

		for pvc in pvc_ids:
			key_candidates = [f'additionalVpn-{pvc}-Info', 'additionalVpnInfo']
			pvc_data = None
			result: dict[str, Any] = {}
			
			for key in key_candidates:
				pvc_data = unwrap_singleton_containers(get_dict_of_key_from_dict(data, key))
				if pvc_data:
					break
			if pvc_data:
				self._update_pvc_result_dict(pvc_data, result, data)
			results[pvc] = result

		return results


	def _update_pvc_result_dict(self, pvc_dic, pvc_result_dict, d):
		for f in self.pvc_fields:
			if isinstance(f, str):
				v = get_value_of_key_from_dict(pvc_dic, f)
				pvc_result_dict[f] = v
			elif isinstance(f, tuple):
				for i, f1 in enumerate(f):
					v = get_value_of_key_from_dict(pvc_dic, f1)
					if i > 0 and not v:
						v = get_value_of_key_from_dict(d, f1)
					if v:
						pvc_result_dict[f1] = v
						break

	def extract_segments_entries(self, pvc_fields, per_fields) -> dict[str, Any]:
		"""Extract segment-specific entries from the dataset."""
		segments_dict = self.extract_segments(self.d)
		# print(segments_dict)
		results: dict[str, dict[str, Any]] = {}
		for segment_key, segment_value in self.segments.items():
			key = segment_value['key']
			# results[key] = {}
			result = results[segment_key] = {}
			segment_fields = segment_value['fields']
			segment_data = segments_dict.get(key)
			if not segment_data: continue
			# ---------------------------------------------------------------------
			if segment_key == 'BGP':
				cust_asn = get_value_of_key_from_dict(segments_dict, 'customerASN')
				if cust_asn and isinstance(cust_asn, list) and len(cust_asn)==1:
					cust_asn = cust_asn[0]
				segment_data.update({"customerASN": cust_asn})
				for field_label, field_key in segment_fields.items():
					result[field_label] = segment_data[field_key] 

			elif segment_key == 'WAN Subnet':
				for field_label, field_key in segment_fields.items():
					if is_duplicate_of_pvc(ip=segment_data[field_key], pvc_fields=pvc_fields): break
					result[field_label] = segment_data[field_key] 

			elif segment_key == 'LAN Subnets':
				ip_field = segment_fields['LAN Subnet']
				mask = segment_fields['SUBNET MASK']
				if isinstance(segment_data, list):
					for i, seg_data in enumerate(segment_data):
						ip_mask = f"{seg_data[ip_field]}/{seg_data[mask]}"
						result[f"LAN Subnet-{i+1}"] = ip_mask
				elif isinstance(segment_data, dict):
					ip_mask = f"{segment_data[ip_field]}/{segment_data[mask]}"
					result['LAN Subnet'] = ip_mask

			elif segment_key == 'PER INFO':
				for field_label, field_key in segment_fields.items():
					if isinstance(segment_data, dict):
						segment_data = [segment_data,]
					for i, sd in enumerate(segment_data):
						segment = sd[segment_fields['Service Segment']]
						if not result.get(segment): result[segment] = {}
						if sd.get(field_key):
							if result[segment].get(field_label):
								if isinstance(result[segment][field_label], str):
									result[segment][field_label] = [result[segment][field_label],] + [sd[field_key],]
								elif isinstance(result[segment][field_label], list):
									result[segment][field_label].append(sd[field_key])
							else:
								result[segment][field_label] = sd[field_key]

			else:
				for field_label, field_key in segment_fields.items():
					result[field_label] = segment_data[field_key] 
			# ---------------------------------------------------------------------


		return results


# ============================================================================================
#  pass
# ============================================================================================
if __name__ == "__main__": pass
# ============================================================================================
