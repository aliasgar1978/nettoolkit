
# ============================================================================================
#  IMPORTS
# ============================================================================================
from pprint import pprint
from abc import abstractmethod
import requests
from dataclasses import dataclass, field

# ============================================================================================
#  STATICS
# ============================================================================================
DYNAMIC_INPUT_DETECTION = True

try:
	from static import LOCAL_RUN
except:
	try:
		from .static import LOCAL_RUN
	except:
		LOCAL_RUN = True
# ============================================================================================
if LOCAL_RUN:
	from static import *
	from common import input_banner, request_banner, json_banner, summary_banner, get_responce, get_value_of_key_from_dict, get_user_inputs
	from dynamic_input import get_dynamic_user_input, return_dynamic_user_input
	from summary import Extract
else:
	from .static import *
	from .common import input_banner, request_banner, json_banner, summary_banner, get_responce, get_value_of_key_from_dict, get_user_inputs
	from .log_gen import append_execution_log
	from .dynamic_input import get_dynamic_user_input, return_dynamic_user_input
	from .summary import Extract
# ============================================================================================

# ============================================================================================

@dataclass
class DataSet():
	# location: str
	ckt_type: str
	ckt_input_type: str
	ckt_input: str
	# collected: set[str] = field(default_factory=set)
	collected: list[str] = field(default_factory=list)
	parent: bool = True

	def __post_init__(self):
		self.responses = {}
		self.get_dataset()
		self.make_api_request_urls()

	def __call__(self):
		self.send_requests()
		if self.parent and self.urls:
			self.update_response_dict_key()
			self.cascaded_results = {}
			self.cascade_requests()

	def get_dataset(self):
		# d = on_location(self.location)
		# d = on_ckt_type(self.ckt_type, d)
		d = on_ckt_type(self.ckt_type)
		d = on_ckt_input_type(self.ckt_input_type, d )
		self.datasets = get_available_req_datasets(d, self.collected)

	def make_api_request_urls(self):
		self.urls = [
			(ds, {"dataset": ds, "version": "1.0", get_key_info(d, self.ckt_input_type): self.ckt_input})
			for ds, d in self.datasets.items()
		]

	def send_requests(self):
		if LOCAL_RUN:
			if not len(self.urls):
				print( f"[-] No known Dataset found for matching request.\n"
						"    Please try with other options.\n"
				)
			if self.parent: print(f"{TILDA80}\n")
		for req_info, api_req_args in self.urls:
			#
			if api_req_args['dataset'] in self.collected:
				print(f"[-] Skipped : API Request {api_req_args}: already sent.")
				return
			#
			if LOCAL_RUN:
				if self.parent:
					print(f"[*] Sending API Request: {api_req_args}")
			else:
				print(".", end='', flush=True)
			response = get_responce(api_req_args)
			self.responses.update( {req_info: response} )
			self.update_json_results(api_req_args)
			if LOCAL_RUN:
				if not response.json().get('result'):
					print(f"[-] No responce received")

	def update_json_results(self, api_req_args):
		self.results = {}
		for req_info, response in self.responses.items():
			try:
				self.results[req_info] = response.json()['result']
				self.collected.append(api_req_args['dataset'])
			except:
				self.results[req_info] = {}



	def update_response_dict_key(self):
		deleted_keys = set()
		for req_info in list(self.results.keys()):
			try:
				info_from = KEY_INFO_MAP[DS_UTIL_MAP[req_info]['ckt_input_type'][0]]
				self.update_result(info_from, self.results[req_info])
				deleted_keys.add(req_info) 
			except: pass
		for dk in deleted_keys:			
			del(self.results[dk])


	def show_response(self):
		if self.urls:
			print(json_banner())
			pprint(self.results)
			print(f"\n{TILDA80}\n")

	def show_summary(self):
		if self.urls:
			print(summary_banner(self.ckt_input))
			ED = Extract(  self.results )
			ED()
		else:
			if not LOCAL_RUN:
				append_execution_log("no urls generated")


	# =============================================================
	#                          CASCASDE
	# =============================================================

	def cascade_requests(self):
		# d = on_location(self.location)
		# d = on_ckt_type(self.ckt_type, d)
		d = on_ckt_type(self.ckt_type)
		datasets = get_available_req_datasets(d, self.collected)
		self._iterate_for_all_available_dataset_items(datasets)

	def _iterate_for_all_available_dataset_items(self, datasets):
		for ds, d in datasets.items():
			self._iterate_for_all_available_api_req_keys_in_dataset(d)

	def _iterate_for_all_available_api_req_keys_in_dataset(self, d):
		for i, api_req_key in enumerate(d['api_req_key']):
			searched_ckt_input_types = search_ckt_input_type_fields(d, api_req_key)
			if searched_ckt_input_types:
				self._iterate_for_all_known_input_type(searched_ckt_input_types, d['ckt_input_type'][i])	

	def _iterate_for_all_known_input_type(self, searched_ckt_input_types, ckt_input_type):
		field_values = set()
		for searched_ckt_input_type in searched_ckt_input_types:
			if searched_ckt_input_type:
				field_values = field_values | get_value_of_key_from_dict(self.results, searched_ckt_input_type)

		for ckt_input in field_values:
			self.cascade_request(ckt_input_type, ckt_input, field_values)

	def cascade_request(self, ckt_input_type, ckt_input, field_values):
		DS = DataSet(
			# location=self.location,
			ckt_type=self.ckt_type,
			ckt_input_type= ckt_input_type,
			ckt_input= ckt_input,
			collected= self.collected,
			parent=False
		)
		DS()
		if DS.responses:
			for info_from, new_result in DS.results.items():
				info_from = KEY_INFO_MAP[DS_UTIL_MAP[info_from]['ckt_input_type'][0]]
				if len(field_values) > 1:
					info_from += f"-{ckt_input}-"
				self.update_result( info_from, new_result )
			if len(field_values) > 1  :
				DS.collected = DS.collected[:-1]
			self.collected = DS.collected


	def update_result(self, info_from, new_result):
		key = f'additional{info_from}Info'
		while self.results.get(key):
			key += "_1"
		self.results[key] = new_result

# // NIU for now // #
def retrive_user_inputs():
	user_inputs = get_user_inputs(USER_INPUTS)
	for k, v in user_inputs.items():
		# if k == 'location':
		# 	user_inputs[k] = LOCATION_MAP[v]
		# if k == 'ckt_type':
		# 	user_inputs[k] = CIRCUIT_TYPE_MAP[v]
		if k == 'ckt_input_type':
			user_inputs[k] = CIRCUIT_INPUT_TYPE_MAP[v]

	# Temporary fixed at AVPN first option since AVPN/ADI both use same both dicts
	if 'ckt_type' not in user_inputs:
		user_inputs['ckt_type'] = CIRCUIT_TYPE_MAP[1]
	# ----------------------------------------------------------------------------

	return user_inputs

# ============================================================================================
#  main
# ============================================================================================

def main(data_input=''):
	# ----------------------------------------
	print(input_banner())
	if not data_input:
		user_inputs = get_manual_entry()
		single_execute(**user_inputs)
	else:
		if not LOCAL_RUN:
			append_execution_log(str(data_input))
		data_inputs = data_input.strip().split()
		for _input in data_inputs:
			user_inputs = return_dynamic_user_input(_input)
			single_execute(**user_inputs)


def get_manual_entry():
	if DYNAMIC_INPUT_DETECTION:
		user_inputs = get_dynamic_user_input()
	else:
		user_inputs = retrive_user_inputs()
	if not user_inputs:
		user_inputs = {}
	if not LOCAL_RUN:
		append_execution_log(str(user_inputs.get('ckt_input')))
	return user_inputs

def single_execute(**user_inputs):
	if not user_inputs: return
	# ----------------------------------------
	print(request_banner())
	DS = DataSet(**user_inputs)
	DS()
	print()
	# ----------------------------------------
	if LOCAL_RUN: 
		DS.show_response()
	DS.show_summary()

# ============================================================================================
if __name__ == '__main__':
	main()
# ============================================================================================
