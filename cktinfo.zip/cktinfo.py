#!/usr/bin/env python3

# ============================================================================================
#  Imports
# ============================================================================================
import sys
import argparse

from circuitInfo import cktInfo

# ============================================================================================

def get_version_info():
    """Returns the version change information of the script."""
    return """
==================================================
cktinfo - Version Change History
==================================================
v1.0 (2026-08-12):
  - Initial deployment.
  - Takes Arbirary user input ( circuit-id, ip-address, isr-number) .
  - Retrives values from icore database using predefined dataset api queries available and, parse json and return output in table.
v1.1 (Inprogress): 
  - Bug fixes (tbd)
==================================================
"""

def main():
    # 1. Initialize the parser with custom description and help formatting
    parser = argparse.ArgumentParser(
    	prog='/home/m98484/bin/cktinfo.sh',
        description="Circuit Information Retrival Utility (cktinfo)",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    # 2. Add the custom version flag (-v or --version)
    # action='store_true' means it sets a boolean flag to True if the user passes it
    parser.add_argument(
        '-v', '--version',
        action='store_true',
        help='Version change information.'
    )

    # 3. Add the arbitrary data input argument
    # nargs='?' makes it optional. If they pass multiple words, they should wrap it in quotes.
    parser.add_argument(
        'data_input',
        nargs='?',
        type=str,
        default=None,
        help='Arbitrary data input string.'
    )

    # 4. Parse the incoming command line arguments
    # Note: argparse automatically provides the -h and --help flags by default.
    args = parser.parse_args()

    # 5. Handle version flag logic
    if args.version:
        print(get_version_info())
        if args.data_input:
            print(f"[-v] flag shows version detail and terminate.\n    To execute data_input remove [-v] and re-run\n==================================================")
        sys.exit(0)

    # 6. Handle arbitrary data input logic
    cktInfo(args.data_input)
    if not args.data_input:
        print(f"{'~'*80}\n"
        	f"[*] Do you know you can send input inline as well along with script name.\n",
            "    Example (single input): /home/m98484/bin/cktinfo.sh 32.245.25.14\n"
            '    Example (multiple input separated by spaces): /home/m98484/bin/cktinfo.sh "32.245.25.14 L4YS.866331..ATI ISR22020774001-0001"\n'
            f"    for more detail see: /home/m98484/bin/cktinfo.sh --help\n{'~'*80}")

# ============================================================================================
#  execute
# ============================================================================================
if __name__ == "__main__": 
    main()
# ============================================================================================

